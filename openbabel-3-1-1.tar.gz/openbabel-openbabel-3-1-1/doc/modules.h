/**
 * @defgroup main Getting Started
 * @defgroup stereo Stereochemistry
 * @defgroup conformer Conformer Searching
 * @defgroup substructure Substructure Searching
 */

/// @file modules.h
/// @brief Doxygen modules declaration.
